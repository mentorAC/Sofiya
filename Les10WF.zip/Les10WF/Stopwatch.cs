﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Les10WF
{
    internal class Stopwatch
    {
        private int msecond;
        private int seconds;
        private int minutes;
    }
}
